<?php
defined('ABSPATH') or die("No script kiddies please!");
/**
 * Adds AccessPress Social Share Widget
 */

class APSS_Widget extends WP_Widget {

	/**
     * Register widget with WordPress.
     */
    function __construct() {
        parent::__construct(
                'apss_widget', // Base ID
                __('AccessPress Social Share Pro', APSS_TEXT_DOMAIN), // Name
                array('description' => __('AccessPress Social Share Widget', APSS_TEXT_DOMAIN)) // Args
        );
    }

    //returns the current page url
    function curPageURL() {
        $pageURL = 'http';
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
            $pageURL .= "s";
        }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
        }
        return $pageURL;
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form($instance) {

        if (isset($instance['title'])) {
            $title = $instance['title'];
        } else {
            $title = '';
        }

        if (isset($instance['theme'])) {
            $theme = $instance['theme'];
        } else {
            $theme = '';
        }

        if (isset($instance['counter'])) {
            $counter = $instance['counter'];
        } else {
            $counter = '0';
        }

        if (isset($instance['widget_color'])) {
            $widget_color = $instance['widget_color'];
        } else {
            $widget_color = '0';
        }

        ?>

        <script type="text/javascript">
        jQuery(document).ready(function($){
            $('.apss_widget_color_picker').wpColorPicker();
        });
        </script>

        <p>

            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title: ', APSS_TEXT_DOMAIN); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('theme'); ?>"><?php _e('Theme: ', APSS_TEXT_DOMAIN); ?></label>
        
        <input class="widefat" id="<?php echo $this->get_field_id('theme'); ?>" name="<?php echo $this->get_field_name('theme'); ?>" type="text" value="<?php echo esc_attr($theme); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('counter'); ?>"><?php _e('Counter Enable ?', APSS_TEXT_DOMAIN); ?></label>
            <input type="radio" name="<?php echo $this->get_field_name('counter'); ?>" <?php if($counter =='1'){echo "checked='checked'"; } ?> value="1">Yes	
			<input type="radio" name="<?php echo $this->get_field_name('counter'); ?>" <?php if($counter =='0'){echo "checked='checked'"; } ?> value="0">No
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('widget_color'); ?>"><?php _e('Widget Background Color: ', APSS_TEXT_DOMAIN); ?></label>
                      <input class="apss_widget_color_picker" id="<?php echo $this->get_field_id('widget_color'); ?>" name="<?php echo $this->get_field_name('widget_color'); ?>" type="text" value="<?php echo esc_attr($widget_color); ?>" />
        </p>

        <?php
    }


     /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance) {

        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        global $post;
        if(have_posts()){
            $widget_flag = get_post_meta($post->ID, 'apss_widget_flag', true);
        }else{
            $widget_flag=0;
        }
        if($widget_flag !='1'){
        $color=$instance['widget_color'];
        echo "<div class='apss-widget' style='background-color: $color'>";
        //echo do_shortcode("[apss-share theme='{$instance['theme']}' counter='{$instance['counter']}']");
?>
<?php
$options = get_option( APSS_SETTING_NAME );
$apss_link_open_option=($options['dialog_box_options']=='1') ? "_blank": "";
$twitter_user=$options['twitter_username'];
$counter_enable_options=$options['counter_enable_options'];
$counter_type_options = $options['counter_type_options'];
$icon_set_value=$options['social_icon_set'];
$url= $this->curPageURL();
$text= get_the_title();
$cache_period = ($options['cache_period'] != '') ? $options['cache_period']*60*60 : 24 * 60 * 60 ;
?>

<?php
if( isset( $instance['theme']) && $instance['theme'] !=''){
    $icon_set_value = $instance['theme'];
}else{
    $icon_set_value = $options['social_icon_set'];
}

    if( isset($attr['networks']) ){
        $raw_array = explode( ',', $attr['networks'] );
        $network_array=array_map('trim', $raw_array );
        $new_array = array();
        foreach( $network_array as $network )
        {
            $new_array[$network] = '1';
        }
        $options['social_networks'] = $new_array;
    }

if(isset($instance['counter'])){
    $counter_enable_options = $instance['counter'];
}else{
    $counter_enable_options = '0';
}
?>

<div class='apss-social-share apss-theme-<?php echo $icon_set_value; ?> <?php if( $counter_enable_options=='1' ){echo 'counter-enable'; } ?> clearfix'>
<?php
global $post;
$title=get_the_title();
$content=strip_shortcodes(strip_tags(get_the_content()));
if(strlen($content) >= 100){
$excerpt= substr($content, 0, 100).'...';
}else{
    $excerpt = $content;
}

foreach( $options['social_networks'] as $key=>$value ){
    if( intval($value)=='1' ){
        switch($key){
            //counter available for facebook
            case 'facebook':
            $link = 'https://www.facebook.com/sharer/sharer.php?u='.$url;
            ?>
            <div class='apss-facebook apss-single-icon'>
                    <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                            <div class='apss-icon-block clearfix'>
                                    <i class='fa fa-facebook'></i>
                                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    
                            </div>
                    <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                    <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                    <?php } ?>
                    </a>
            </div>
            <?php 
            break;

            //counter available for twitter
            case 'twitter':
            $url_twitter = $url;
            $url_twitter=urlencode($url_twitter);
            if(isset( $twitter_user) && $twitter_user !='' ){
                $twitter_user = 'via='.$twitter_user;
            }
            $link ="https://twitter.com/intent/tweet?text=$title&amp;url=$url_twitter&amp;$twitter_user";
            ?>
            <div class='apss-twitter apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['twitter-long-text']) && $options['share_texts']['twitter-long-text'] !='' ){ echo $options['share_texts']['twitter-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                        <i class='fa fa-twitter'></i>
                        <span class='apss-social-text'><?php if(isset($options['share_texts']['twitter-long-text']) && $options['share_texts']['twitter-long-text'] !='' ){ echo $options['share_texts']['twitter-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                        <span class='apss-share'><?php if(isset($options['share_texts']['twitter-short-text']) && $options['share_texts']['twitter-short-text'] !='' ){ echo $options['share_texts']['twitter-short-text']; }else{ echo "Tweet"; } ?></span>
                    </div>
                    <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                    <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                    <?php } ?>
                </a>
            </div>
            <?php
            break;

            //counter available for google plus
            case 'google-plus':
            $link = 'https://plus.google.com/share?url='.$url;
            ?>
            <div class='apss-google-plus apss-single-icon'>
            <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo 'Google Plus'; } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                <div class='apss-icon-block clearfix'>
                    <i class='fa fa-google-plus'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo 'Google Plus'; } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                </div>
                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>
                </a>
            </div>
            <?php
            break;

            //counter available for pinterest
            case 'pinterest':
            ?>

            <div class='apss-pinterest apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' href='javascript:pinIt();'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-pinterest'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>

                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>

                </a>
            </div>
            <?php
            break;
            
            //couter available for linkedin
            case 'linkedin':
            $link = "http://www.linkedin.com/shareArticle?mini=true&amp;title=".$title."&amp;url=".$url."&amp;summary=".$excerpt;
            ?>
            <div class='apss-linkedin apss-single-icon'>
            <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                <div class='apss-icon-block clearfix'><i class='fa fa-linkedin'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                </div>

                <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                <?php } ?>

            </a>
            </div>
            <?php
            break;

            //there is no counter available for digg
            case 'digg':
            $link = "http://digg.com/submit?phase=2%20&amp;url=".$url."&amp;title=".$title;
            ?>
            <div class='apss-digg apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                <div class='apss-icon-block clearfix'>
                    <i class='fa fa-digg'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                </div>
            </a>
            </div>

            <?php
            break;

            //counter available for delicious
            case 'delicious':
            $link = "https://delicious.com/save?url=$url&title=".$title;
            ?>

            <div class='apss-delicious apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                        <i class='fa fa-delicious'></i>
                        <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                        <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>
                </a>
            </div>

            <?php
            break;

            //counter available for reddit 
            case 'reddit':
            $link ="http://www.reddit.com/submit?url=$url&title=".$title;
            ?>

            <div class='apss-reddit apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-reddit'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>
                </a>
            </div>
            <?php
            break;

            //counter available for stumbleupon
            case 'stumbleupon':
            $link = "http://www.stumbleupon.com/badge/?url=".$url;
            ?>

            <div class='apss-stumbleupon apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-stumbleupon'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>
                </a>
            </div>
            <?php break;

            //counter not available for tumblr
            case 'tumblr':
            $link = "http://www.tumblr.com/share/link?url=$url&name=".$title."&description=".$excerpt." title='".$title."'";
            ?>
            <div class='apss-tumblr apss-single-icon'>
            <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                <div class='apss-icon-block clearfix'>
                    <i class='fa fa-tumblr'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                </div>
                </a>
            </div>
            <?php
            break;


            //counter available for vkontakte
            case 'vkontakte':
            $link = "http://vkontakte.ru/share.php?url=".$url;
            ?>

            <div class='apss-vk apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-vk'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                        <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                        <?php } ?>
                </a>
            </div>
            <?php
            break;


            //there is no counter available for xing
            case 'xing':
            $link = "https://www.xing.com/spi/shares/new?url=".$url;
            ?>
            <div class='apss-xing apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-xing'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                </a>
            </div>
            <?php 
            break;

            //counter not available for weibo
            case 'weibo':
            $image[0]='';
            if(has_post_thumbnail()){
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
            }
            $link = "http://service.weibo.com/share/share.php?url=$url&appkey=&title=".$title."&pic=".$image[0];
            ?>
            <div class='apss-weibo apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-weibo'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>
                </a>
            </div>
            <?php 
            break;

            //counter available for buffer
            case "buffer":
            $link = "https://bufferapp.com/add?url=$url&text=".$title."&via=&picture=&count=horizontal&source=button";
            ?>

            <div class='apss-buffer apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa fa-buffer'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['common-long-text']) && $options['share_texts']['common-long-text'] !='' ){ echo $options['share_texts']['common-long-text']; }else{ echo "Share on"; } ?> <?php if(isset($options['apss_social_networks_naming'][$key]) && $options['apss_social_networks_naming'][$key] !='' ){ echo $options['apss_social_networks_naming'][$key]; }else{ echo ucfirst($key); } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['common-short-text']) && $options['share_texts']['common-short-text'] !='' ){ echo $options['share_texts']['common-short-text']; }else{ echo "Share"; } ?></span>
                    </div>

                    <?php if(isset($counter_enable_options) && $counter_enable_options=='1'){ ?>
                        <div class='count apss-count' data-url='<?php echo $url;?>' data-social-network='<?php echo $key; ?>' data-social-detail="<?php echo $url.'_'.$key;?>">Loading...</div>
                    <?php } ?>

                </a>
            </div>
            <?php
            break;

            case 'email':
                    if ( strpos( $options['apss_email_body'], '%%' ) || strpos( $options['apss_email_subject'], '%%' ) ) {
                        $link = 'mailto:?subject='.$options['apss_email_subject'].'&amp;body='.$options['apss_email_body'];
                        $link = preg_replace( array( '#%%title%%#', '#%%siteurl%%#', '#%%permalink%%#', '#%%url%%#' ), array( get_the_title(), get_site_url(), get_permalink(), $url ), $link );
                    }
                    else {
                        $link = 'mailto:?subject='.$options['apss_email_subject'].'&amp;body='.$options['apss_email_body'].": ".$url;
                    }
                    ?>
            <div class='apss-email apss-single-icon'>
                <a class='share-email-popup' title='<?php if(isset($options['share_texts']['email-long-text']) && $options['share_texts']['email-long-text'] !='' ){ echo $options['share_texts']['email-long-text']; }else{ echo "Send email"; } ?>' target='<?php echo $apss_link_open_option; ?>' href='<?php echo $link; ?>'>
                    <div class='apss-icon-block clearfix'>
                    <i class='fa  fa-envelope'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['email-long-text']) && $options['share_texts']['email-long-text'] !='' ){ echo $options['share_texts']['email-long-text']; }else{ echo "Send email"; } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['email-short-text']) && $options['share_texts']['email-short-text'] !='' ){ echo $options['share_texts']['email-short-text']; }else{ echo "Mail"; } ?></span>
                    </div>
                </a>
            </div>

            <?php
            break;

            case 'print':
            ?>
            <div class='apss-print apss-single-icon'>
                <a title='<?php if(isset($options['share_texts']['print-long-text']) && $options['share_texts']['print-long-text'] !='' ){ echo $options['share_texts']['print-long-text']; }else{ echo "Print this"; } ?>' href='javascript:void(0);' onclick='window.print();return false;'>
                    <div class='apss-icon-block clearfix'><i class='fa fa-print'></i>
                    <span class='apss-social-text'><?php if(isset($options['share_texts']['print-long-text']) && $options['share_texts']['print-long-text'] !='' ){ echo $options['share_texts']['print-long-text']; }else{ echo "Print this"; } ?></span>
                    <span class='apss-share'><?php if(isset($options['share_texts']['print-short-text']) && $options['share_texts']['print-short-text'] !='' ){ echo $options['share_texts']['print-short-text']; }else{ echo "Print"; } ?></span>
                    </div>
                </a>
            </div>
            <?php 
            break;
    
            }
    }

}   

?>
</div>



<?php
        echo "</div>";
        }
        echo $args['after_widget'];
    }


    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title']) ) ? strip_tags($new_instance['title']) : '';
        $instance['theme'] = (!empty($new_instance['theme']) ) ? strip_tags($new_instance['theme']) : '';
        $instance['counter'] = (!empty($new_instance['counter']) ) ? strip_tags($new_instance['counter']) : '0';
        $instance['widget_color'] =(!empty($new_instance['widget_color'])) ? strip_tags($new_instance['widget_color']) : '';
        return $instance;
    }



}

?>