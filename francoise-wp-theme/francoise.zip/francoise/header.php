<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<title><?php wp_title(); ?></title>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<!--[if lte IE 8]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<!--[if lt IE 8]>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script>
		<![endif]-->
		<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico" type="image/x-icon" />
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo get_stylesheet_directory_uri(); ?>/apple-touch-icon-144x144.png" />
        <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo get_stylesheet_directory_uri(); ?>/apple-touch-icon-152x152.png" />
        <link rel="icon" type="image/png" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon-32x32.png" sizes="32x32" />
        <link rel="icon" type="image/png" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon-16x16.png" sizes="16x16" />

        <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php echo bloginfo('rss2_url'); ?>">

        <!-- wp_header -->
        <?php
        if ( is_singular() ) wp_enqueue_script( "comment-reply" );
        wp_head(); ?>

<?php
if ( ot_get_option('uni_google_fonts') ) {
    $aCustomFonts = ot_get_option('uni_google_fonts');
    $ot_google_fonts      = get_theme_mod( 'ot_google_fonts', array() );
    $sFontNameOne = $sFontNameTwo = '';
    if ( !empty($aCustomFonts[0]) ) $sFontNameOne = $ot_google_fonts[$aCustomFonts[0]["family"]]['family'];
    if ( !empty($aCustomFonts[1]) ) $sFontNameTwo = $ot_google_fonts[$aCustomFonts[1]["family"]]['family'];
?>
<style type="text/css">
body, table, input, textarea, select, li, button, p, blockquote, ol, dl, form, pre, th, td, a,
.singlePostTime, .archivePostTime, .blogPostTime, .blogPostListTime,
.archivePostItem p,
.archivePostItemComments, .archivePostItemComments:visited,
.postTime,
.archivePostReadMore, .archivePostReadMore:visited,
.postPagination ul li.threeDot,
.postPagination ul li.current,
.postPagination ul li a, .postPagination ul li a:visited,
.aboutMeWidget p,
.popularPostsWidgetItem time,
.twitterSliderItem p,
.twitterSliderItem time,
.left-quote, .right-quote,
.tagcloud a, .tagcloud a:visited,
.subscribeWidget p,
.textwidget p,
.sidebar-widget ul.menu li a, .sidebar-widget ul.menu li a:visited,
.sidebar-widget > ul > li li a, .sidebar-widget > ul > li li a:visited,
.sidebar-widget > ul > li > a, .sidebar-widget > ul > li > a:visited,
.sidebar-widget > ul > li li a:hover,
.sidebar-widget ul.menu li a:hover,
.sidebar-widget > ul > li > span.comment-author-link,
.sidebar-widget > ul > li > span a,
.rssSummary,
.rss-date,
#wp-calendar caption,
#wp-calendar thead th,
#wp-calendar tbody td,
#wp-calendar tfoot td a, #wp-calendar tfoot td a:visited,
.copyright,
.blogPostListItem p, .blogPostItem p,
.archivePageTitle h1,
.noResultsWrap p, .page404Wrap p,
.pageAboutDesc p, .pageContactDesc p,
.singlePostWrap,
.singlePostWrap p,
.singlePostWrap .wp-caption-text, .singlePostWrap .gallery-caption,
.singlePostWrap blockquote:before,
.singlePostWrap blockquote p,
.singlePostWrap blockquote p a, .singlePostWrap blockquote p a:visited,
.singlePostWrap table th,
.singlePostWrap table th a, .singlePostWrap table th a:visited,
.singlePostWrap table td,
.singlePostWrap table td a, .singlePostWrap table td a:visited,
.singlePostWrap dt,
.singlePostWrap dd,
.singlePostWrap ul li, .singlePostWrap ol li,
.singlePostWrap ol li:before,
.singlePostWrap p a, .singlePostWrap p a:visited, .singlePostWrap ul li a, .singlePostWrap ul li a:visited,
.singlePostWrap ol li a, .singlePostWrap ol li a:visited,
.singlePostWrap address,
.singlePostWrap .su-list ul li,
.singlePostWrap .su-tabs-nav span,
.singlePostWrap .su-tabs-pane,
.singlePostWrap .su-quote-cite a,
.singlePostWrap .su-divider a,
.singlePostWrap .su-heading-style-default .su-heading-inner,
.singlePostWrap .su-service-title,
.singlePostWrap .su-label,
.singlePostWrap .su-spoiler-title,
.singlePostWrap .su-carousel .su-carousel-slide-title,
.singlePostWrap .su-slider-slide-title,
.singlePostTags,
.singlePostTags a, .singlePostTags a:visited,
.postNavigationItem a, .postNavigationItem a:visited,
.logged-in-as,
.logged-in-as a, .logged-in-as a:visited,
.comment-metadata time,
.comment-content p, .comment-awaiting-moderation,
.comment-content p a, .comment-content p a:visited,
.comment-content blockquote p,
.comment-content blockquote p a, .singlePostWrap blockquote p a:visited,
.comment-content table th,
.comment-content table th a, .comment-content table th a:visited,
.comment-content table td,
.comment-content table td a, .comment-content table td a:visited,
.comment-content dt,
.comment-content dd,
.comment-content ul li, .comment-content ol li,
.comment-content ol li:before,
.comment-content p a, .comment-content p a:visited, .comment-content ul li a, .comment-content ul li a:visited,
.comment-content ol li a, .comment-content ol li a:visited,
.comment-content address {font-family: '<?php echo $sFontNameOne; ?>';}

.comment-content blockquote p cite {font-family: '<?php echo $sFontNameOne; ?>'!important;}

/* headings */
.mainMenu li a, .mainMenu li a:visited,
.homeV1PostDesc h3,
.archivePostTitle a, .archivePostTitle a:visited,
.postCategoryWrap,
.singlePostCategory, .singlePostCategory:visited, .archivePostCategory, .archivePostCategory:visited,
.sidebar-widget h3,
.popularPostsWidgetItem h4 a, .popularPostsWidgetItem h4 a:visited,
.subscribeWidget form input[type="text"],
.sidebar-widget .search-form .search-field,
select[name="archive-dropdown"],
.sbi_header_link,
.searchPopup form input[type="text"],
.footerSocialItem a, .footerSocialItem a:visited,
.footerMenu li a, .footerMenu li a:visited,
.blogPostListItem h3 a, .blogPostListItem h3 a:visited, .blogPostItem h3 a, .blogPostItem h3 a:visited,
.twitterUsername,
.homePageLink, .homePageLink:visited,
.noResultsTitle,
.pageAboutDesc h1, .pageContactDesc h1,
.pageAboutDesc .locationDesc,
.contactForm h3,
.contactForm .form-row label,
.contactForm .form-row textarea, .contactForm .form-row input[type="text"], .contactForm .form-row input[type="password"],
.submitContactFormBtn,
.contactForm .wpcf7-form p,
.wpcf7-form .wpcf7-quiz,
.wpcf7-form .wpcf7-text,
.wpcf7-form .wpcf7-range,
.wpcf7-form .wpcf7-date,
.wpcf7-form textarea,
.wpcf7-form input[type="submit"],
.wpcf7-form select,
.singlePostMeta h1,
.singlePostWrap h1, .singlePostWrap h2, .singlePostWrap h3, .singlePostWrap h4, .singlePostWrap h5, .singlePostWrap h6,
.singlePostTags span,
.postNavigationItem p,
.relatedPostsBox h3,
.relatedPostDesc h4,
.commentsBox h2.comments-title, .commentsBox h3.comment-reply-title,
.commentsBox h3.comment-reply-title a, .commentsBox h3.comment-reply-title a:visited,
.comment-edit-link, .comment-edit-link:visited, .comment-reply-link, .comment-reply-link:visited,
.comment-wrapper cite.fn,
.comment-wrapper span.uni-post-author,
.comment-wrapper cite.fn a,
.comment-content h1, .comment-content h2, .comment-content h3, .comment-content h4, .comment-content h5, .comment-content h6,
#commentform p label,
#commentform input[type="text"],
#commentform textarea,
#commentform textarea,
#commentform #submit {font-family: '<?php echo $sFontNameTwo; ?>';}


#uni_popup, .contactForm .wpcf7-validation-errors,
.wpcf7-response-output.wpcf7-mail-sent-ok {font-family: '<?php echo $sFontNameTwo; ?>'!important;}
</style>
<?php } ?>

	</head>
<body <?php body_class(); ?>>
	<header id="header">
		<div class="siteHeader">
			<div class="wrapper clear">
				<a href="<?php if ( function_exists('icl_get_languages') ) { echo esc_url( icl_get_home_url() ); } else { echo esc_url( home_url() ); } ?>" class="mobile-logo">
                <?php
                $iLogoMobileAttachId = ( ot_get_option( 'uni_logo_mobile' ) ) ? ot_get_option( 'uni_logo_mobile' ) : '';
                if ( !empty($iLogoMobileAttachId) ) {
                    $aLogoMobileImage = wp_get_attachment_image_src( $iLogoMobileAttachId, 'full' );
                    $sLogoMobileImage = $aLogoMobileImage[0];
                    echo '<img src="'.esc_url($sLogoMobileImage).'" alt="'.esc_attr(get_bloginfo('description')).'">';     
                } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/mobile-logo.png" alt="<?php echo esc_attr( get_bloginfo('name') ) ?>">
                <?php } ?>
				</a>

                <?php $iSocialsCount = 0; ?>
				<div class="pull-right clear">
					<div class="headerSocialLinks clear">
                    <?php if ( ot_get_option( 'uni_email_link' ) ) { $iSocialsCount++; ?>
			        <a href="<?php echo ot_get_option( 'uni_email_link' ) ?>" target="_blank"><i class="fa fa-envelope"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_fb_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_fb_link' ) ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_youtube_link' ) ) { $iSocialsCount++; ?>
			        <a href="<?php echo ot_get_option( 'uni_youtube_link' ) ?>" target="_blank"><i class="fa fa-youtube-play"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_vimeo_link' ) ) { $iSocialsCount++; ?>
			        <a href="<?php echo ot_get_option( 'uni_vimeo_link' ) ?>" target="_blank"><i class="fa fa-vimeo"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_tw_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_tw_link' ) ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_in_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_in_link' ) ?>" target="_blank"><i class="fa fa-instagram"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_li_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_li_link' ) ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_bl_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_bl_link' ) ?>" target="_blank"><i class="fa fa-heart"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_pi_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_pi_link' ) ?>" target="_blank"><i class="fa fa-pinterest"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_gp_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_gp_link' ) ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_fs_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_fs_link' ) ?>" target="_blank"><i class="fa fa-foursquare"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_fl_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_fl_link' ) ?>" target="_blank"><i class="fa fa-flickr"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_dr_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_dr_link' ) ?>" target="_blank"><i class="fa fa-dribbble"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_be_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_be_link' ) ?>" target="_blank"><i class="fa fa-behance"></i></a>
                    <?php } ?>
                    <?php if ( ot_get_option( 'uni_vk_link' ) ) { $iSocialsCount++; ?>
        			<a href="<?php echo ot_get_option( 'uni_vk_link' ) ?>" target="_blank"><i class="fa fa-vk"></i></a>
                    <?php } ?>
					</div>
					<div class="searchIcon"></div>
				</div>

                <?php $sClassForMenu = 'width-11-' . $iSocialsCount; ?>
                <?php if ( has_nav_menu('primary') ) {
                    wp_nav_menu( array( 'container' => 'nav', 'container_class' => $sClassForMenu, 'menu_class' => 'mainMenu clear', 'theme_location' => 'primary', 'depth' => 3, 'fallback_cb'=> '' ) );
                    } else {
                        uni_nav_fallback( $sClassForMenu );
                    } ?>

				<span class="showMobileMenu">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</span>
			</div>
		</div>
		<a href="<?php if ( function_exists('icl_get_languages') ) { echo esc_url( icl_get_home_url() ); } else { echo esc_url( home_url() ); } ?>" class="logo">
        <?php
        $iLogoAttachId = ( ot_get_option( 'uni_logo_desktop' ) ) ? ot_get_option( 'uni_logo_desktop' ) : '';
        if ( !empty($iLogoAttachId) ) {
            $aLogoImage = wp_get_attachment_image_src( $iLogoAttachId, 'full' );
            $sLogoImage = $aLogoImage[0];
            echo '<img src="'.esc_url($sLogoImage).'" alt="'.esc_attr(get_bloginfo('description')).'">';
        } else { ?>
		    <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php echo esc_attr( get_bloginfo('name') ) ?>">
        <?php } ?>
        </a>
	</header>